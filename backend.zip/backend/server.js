import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { database } from './database.js'

const app = express()
const port = process.env.PORT || 5050

app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }))
app.use(express.json({ limit: '20kb' }))

app.get('/api/health', (_request, response) => response.json({ status: 'ok' }))

app.post('/api/contact', async (request, response) => {
  const { name, email, subject, message } = request.body || {}
  if (![name, email, subject, message].every((value) => typeof value === 'string' && value.trim())) {
    return response.status(400).json({ error: 'Name, email, subject, and message are required.' })
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return response.status(400).json({ error: 'Please provide a valid email address.' })
  }
  try {
    const result = await database.run(
      'INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)',
      [name.trim(), email.trim(), subject.trim(), message.trim()]
    )
    return response.status(201).json({ id: result.lastID, message: 'Contact message saved successfully.' })
  } catch (error) {
    console.error('Failed to save contact message:', error)
    return response.status(500).json({ error: 'Unable to save your message right now.' })
  }
})

app.get('/api/contact', async (_request, response) => {
  try {
    const contacts = await database.all('SELECT id, name, email, subject, message, created_at FROM contacts ORDER BY created_at DESC')
    return response.json(contacts)
  } catch (error) {
    console.error('Failed to retrieve contact messages:', error)
    return response.status(500).json({ error: 'Unable to retrieve contact messages.' })
  }
})

app.listen(port, () => console.log(`Portfolio API listening on port ${port}`))
